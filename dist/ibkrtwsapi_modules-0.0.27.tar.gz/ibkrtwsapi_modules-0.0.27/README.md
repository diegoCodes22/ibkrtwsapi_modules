Simple package to simplify coding with the Interactive Brokers Trader Workstation API.\
Easily request current asset price, historical data, price at a given time, etc.\
Convert data to pandas dataframe.\
Request account and portfolio information.\
l
