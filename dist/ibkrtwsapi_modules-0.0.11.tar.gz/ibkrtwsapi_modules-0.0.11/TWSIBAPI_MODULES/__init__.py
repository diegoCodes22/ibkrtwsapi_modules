class NoSecDef(Exception):
    pass
