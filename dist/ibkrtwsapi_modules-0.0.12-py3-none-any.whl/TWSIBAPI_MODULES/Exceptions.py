class NoSecDef(Exception):
    pass

