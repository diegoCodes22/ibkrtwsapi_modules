# Add to Configurations object the max time for open orders
# Cancel orders after price movement
